package assistedpractice.ExceptionHandlers;

public class Example1 {

}
